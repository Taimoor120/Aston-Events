<!DOCTYPE html>
<html lang="en">



	<head>

		<meta charset="utf-8"/>
		<title> Aston Events </title>
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
	    rel="stylesheet">
	  <link href="https://cdnjs.cloudflare.com/ajax/libs/normalize/4.2.0/normalize.min.css" rel="stylesheet" />
		<link href="addEvents.css" rel="stylesheet" />
		<a href="http://www.aston.ac.uk/"><img src="Aston-logo.jpg" height="80px" width="250px"/> </a>

	</head>


	<body>

		<header id="main-header">
		<h1> Aston Event </h1>

    <div class="welcome">

    <?php
    session_start();
    if (isset($_SESSION['email'])){
      echo "&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp Welcome ".$_SESSION['email'];
    }else {
      echo "didnt work";
    }
    ?>

        </div>

		<ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="event.php">Events</a></li>
		<li><a href="contactUs.php">Contact Us</a></li>
    <li><a href="index.php">Log Out</a></li>
		</ul>

		</header>

		<form class="event" action="addEventdb.php" method="post" enctype="multipart/form-data">
			<div class="header2">
			 <h2>Orgnaise Your Own Event</h2>
		 </div>

		 <div class = "wrap">

        <label class ="organiser">Organiser Details</label>

				<br> <br>
			 <input type = "text" name="organiser" placeholder="Name Of Organiser">
			 <input type="email"name="email"placeholder="Organiser email"pattern=".+\.ac\.uk"title="Please enter a Aston University email address"/>

			 <p> </P>
       <label class ="details">Event Details</label>

			 <br> </br>
			<input type = "text" name="name" placeholder="Name Of Event">


			<select name="type">


        <option value="sport">Sport (e.g. Football, Swimming, Cricket etc.)</option>
        <option value="culture">Culture (e.g. Hindu, Jewish, Chinese etc.)</option>
				<option value="other">Others (Music, Photography etc.)</option>
      </select>


			<input type="date" name="date">
			<input type="time" name="time">

			<input type = "text" name="venue" placeholder="Venue">

      <br> </br>
			<label class ="description">Event Description</label>
			<div class="box">
			<textarea name="comments" style="width:48.5%;height:140px;border:none;padding:2%;font:18px/30px sans-serif;">
			</textarea>
			</div>

			 <p> </p>

			 <input type="submit" value= "Submit" name="Submit">
		 </div>

		</form>

		</div>


  </body>

</html>
