<?php

include('connect.php');
session_start();
// only run the php script if form is submitted
if (isset($_POST["Submit"])) {


  $organiser = $_POST['organiser'];
  $email = $_POST['email'];
  $name = $_POST['name'];
  $type = $_POST['type'];
  $date = $_POST['date'];
  $time = $_POST['time'];
  $venue = $_POST['venue'];
  $description = $_POST['comments'];


  if (empty($organiser))
  {
    echo '<a href="addEvent.php">Please type in your name<br /></a>';
      return false;
  }

  if (empty($email))
  {
  echo '<a href="addEvent.php">Please type in your email<br /></a>';
  return false;
  }

  if (empty($name))
  {
    echo '<a href="addEvent.php">Please type in the name of your event<br /></a>';
  return false;
  }

  if (empty($type))
  {
  echo '<a href="addEvent.php">Please specify the type of your event<br /></a>';
  return false;
  }

  if (empty($date))
  {
  echo '<a href="addEvent.php">please specify the date of your event<br /></a>';
  return false;
  }

  if (empty($time))
  {

  echo '<a href="addEvent.php">please specify the time of your event<br /></a>';
  return false;
  }

  if (empty($venue))
  {
  echo '<a href="addEvent.php">please specify the venue of your event<br /></a>';
  return false;
  }

  if (empty($description))
  {
  echo '<a href="addEvent.php">please give a description of your event<br /></a>';
  return false;
  }


  try{
    // use the form data to create a insert SQL and  add a event record
    $sth=$db->prepare("INSERT INTO events(organiser,email,event,type,date,time,venue,description) VALUES('$organiser','$email','$name','$type','$date','$time','$venue','$description')");
    $sth->execute(array($organiser,$email,$name,$type,$date,$time,$venue,$description));
    header('location:event.php');


  } catch (PDOException $ex){
    //this catches the exception when it is thrown
    echo "Sorry, a database error occurred when trying to insert a record. Please try again.<br> ";
    echo "Error details:". $ex->getMessage();
  }

} else {

  echo "failed";
}

  ?>
