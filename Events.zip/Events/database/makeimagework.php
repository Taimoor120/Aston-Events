<?php

$image = addslashes(file_get_contents($_FILES['image']['tmp_name']));


?>
