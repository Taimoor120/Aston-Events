<!DOCTYPE html>
<html lang="en">

	<head>

		<meta charset="utf-8"/>
		<title> Aston Events </title>
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
	    rel="stylesheet">
	  <link href="https://cdnjs.cloudflare.com/ajax/libs/normalize/4.2.0/normalize.min.css" rel="stylesheet" />
		<link href="Home.css" rel="stylesheet" />
		<a href="http://www.aston.ac.uk/"><img src="Aston-logo.jpg" height="80px" width="250px"/> </a>

	</head>


	<body>

		<header id="main-header">
		<h1> Aston Event </h1>

		<?php
		session_start();

		if(!isset($_SESSION['email'])){
			?>

		<ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="signUp.php">Sign Up</a></li>
		<li><a href="event.php">Events</a></li>
		<li><a href="contactUs.php">Contact Us</a></li>
		</ul>


			<form class="sign_In" action="login.php" method="post">

			<input type="email"name="email"placeholder="Email"pattern=".+\.ac\.uk"title="Please enter a Aston University email address"required/>
			<input type="password" name="password" placeholder="Password" required/>
			<input type="submit"  name="sign">

		</form>
<?php
} else {
?>
<ul>
<li><a href="index.php">Home</a></li>
<li><a href="event.php">Events</a></li>
<li><a href="contactUs.php">Contact Us</a></li>
<li><a name="out" href="logOut.php">Log Out</a></li>
</ul>

<span style="color:white;text-align:center;position:relative;bottom:75px;left:10px;font-weight:bold;" ><?php echo "Welcome " .$_SESSION['email']?></span>';
<?php
	}
	?>

		</header>

		<main>

			<section id="join-up-message">
				<h2> Turning ideas into action.</h2>
				<p>
				Organise your own event now!!!!!
				</p>

				<input type="button" onclick="location.href='signUp.php';" value="Sign Up Now!" />
			</section>

			<section id="benefits">
				<h2> WHY SIGN UP?</h2>
				<div class="benefits">
				<i class="material-icons">grade</i>
				<p>
				Publish your own events.
				</p>
				</div>

				<div class="benefits">
				<i class="material-icons">grade</i>
				<p class="benefit2">
				Have the status of an "Event Organiser".
				</p>
				</div>

				<div class="benefits">
				<i class="material-icons">grade</i>
				<p>
				Improve your reputation.
				</p>
				</div>

			</section>

			<section id="testimonials">
				<h2> Types Of Events</h2>
				<div>
				    <p style="float: right;"><img src="https://previews.123rf.com/images/raphtong/raphtong0809/raphtong080900149/3605747-logos-of-sports-sports-competitions-buttons-black-on-white-background.jpg" height="100px" width="100px" border="1px"></p>
				    <p> Sport (e.g. Football, Swimming, Cricket etc.)</p>
				</div>

				<div style="clear: right;">
				    <p style="float: right;"><img src="https://previews.123rf.com/images/peterhermesfurian/peterhermesfurian1701/peterhermesfurian170100001/68415425-symbols-of-world-religions-nine-signs-of-major-religious-groups-and-principle-religions-christianity.jpg" height="100" width="100" border="1px"></p>
				    <p> Culture (e.g. Hindu, Jewish, Chinese etc.)</p>
				</div>

				<div style="clear: right;">
						<p style="float: right;"><img src="https://comps.canstockphoto.com/sketch-of-a-male-photographer-takes-clipart-vector_csp25464350.jpg" height="100" width="100" border="1px"></p>
						<p> Others (Music, Photography etc.)</p>
				</div>

			</section>
		</main>


	</body>

</html>
