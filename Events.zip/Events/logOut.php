<?php
    if(!isset($_SESSION))
    {
        session_start();
    }
  //when login button selected
  if(!isset($_POST['out'])){
    $_SESSION['email'] = "";
    session_destroy();
    header("location:index.php");
  } else {
    $msg = "invalid username and password";
    echo $msg;
  }

?>
