<?php


include('connect.php');
session_start();

$msg = "";

if(isset($_POST['sign'])) {
  $email = trim($_POST['email']);
  $password = md5($_POST['password']);
  echo $password;

  if($email != "" && $password != "") {

    try {
      $query= "SELECT * FROM information WHERE email='$email' AND password='$password'";
      $stmt = $db->prepare($query);
      $stmt->bindParam('email', $email, PDO::PARAM_STR);
      $stmt->bindValue('password', $password, PDO::PARAM_STR);
      $stmt->execute();
      $count = $stmt->rowCount();
      $row   = $stmt->fetch(PDO::FETCH_ASSOC);

      if($count == 1 && !empty($row)) {
        $_SESSION['email']   = $row['email'];
        header('location:index.php');

      } else {
         echo "Invalid email and password!";
        header('location:index.php');
      }

    } catch (PDOException $e) {
      echo "Error : ".$e->getMessage();
    }

  } else {
    $msg = "Both fields are required!";
  }
}


?>
