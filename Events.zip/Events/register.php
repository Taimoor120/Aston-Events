<?php


    include('connect.php');
    session_start();
    // only run the php script if form is submitted
    if (isset($_POST["Submit"])) {

    	$name = $_POST['name'];
    	$email = $_POST['email'];
    	$mobile = $_POST['mobile'];
      $password = md5($_POST['password1']);
      $confirm = md5($_POST['confirm']);
      $dob = $_POST['year'].$_POST['month'].$_POST['day'];

      if (empty($name))
      {
        echo '<a href="signUp.php">Please type in your name<br /></a>';
          return false;
      }

      if (empty($email))
      {
      echo '<a href="signUp.php">Please type in your email<br /></a>';
      return false;
      }

      if (empty($mobile))
      {
      echo '<a href="signUp.php">Please type in your mobile<br /></a>';
      return false;
      }

      if (empty($password))
      {
      echo '<a href="signUp.php">Please type in your password<br /></a>';
      return false;
      }

      if (empty($confirm))
      {

        echo '<a href="signUp.php">Please confirm your password<br /></a>';
      return false;
      }

      if (!isset($_POST['gender']))
      {
      echo '<a href="signUp.php">Please select your gender<br /></a>';
      return false;
      }
      $gender = $_POST['gender'];
      if ($password != $confirm) {
      echo("Passwords do not match");
      return false;
      }


    	try{
    		// use the form data to create a insert SQL and  add a organiser record
    		$sth=$db->prepare("INSERT INTO information(name,email,mobile,password,confirm,gender,dob) VALUES('$name','$email','$mobile','$password','$confirm','$gender','$dob')");
        $_SESSION['email']=$email;
        $sth->execute(array($name,$email,$mobile,$password,$confirm,$gender,$dob));
        header('location:signed.php');

    	} catch (PDOException $ex){
    		//this catches the exception when it is thrown
    		echo "Error details:". $ex->getMessage();
        echo '<a href="signUp.php">Go Back<br /></a>';
    	}
    }


    ?>
