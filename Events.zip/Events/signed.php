<!DOCTYPE html>
<html lang="en">


	<head>

		<meta charset="utf-8"/>
		<title> Aston Events </title>
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
	    rel="stylesheet">
	  <link href="https://cdnjs.cloudflare.com/ajax/libs/normalize/4.2.0/normalize.min.css" rel="stylesheet" />
		<link href="signed.css" rel="stylesheet" />
		<a href="http://www.aston.ac.uk/"><img src="Aston-logo.jpg" height="80px" width="250px"/> </a>

	</head>


	<body>

		<header id="main-header">
		<h1> Aston Event </h1>

		<?php
		session_start();

		if(!isset($_SESSION['email'])){
			?>

		<ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="signUp.php">Sign Up</a></li>
		<li><a href="event.php">Events</a></li>
		<li><a href="contactUs.php">Contact Us</a></li>
		</ul>

			<form class="sign_In" action="login.php" method="post">

			<input type="email"name="email"placeholder="Email"pattern=".+\.ac\.uk"title="Please enter a Aston University email address"required/>
			<input type="password" name="password" placeholder="Password" required/>
			<input type="submit"  name="sign">

		</form>
		<?php
		} else {
		?>
		<ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="event.php">Events</a></li>
		<li><a href="contactUs.php">Contact Us</a></li>
		<li><a name="out" href="logOut.php">Log Out</a></li>
		</ul>

		<span style="color:white;text-align:center;position:relative;bottom:75px;left:10px; font-weight:bold;" ><?php echo "Welcome " .$_SESSION['email']?></span>';
		<?php
		}
		?>

		</header>

		<h2> Welcome to Aston Events, You can now organise your own events. </h2>

		<h3> Now Begin Your Journey </h3>

		<div class="ready">

		<img src="https://objects.artspan.com/member/marahbr/1200/2142133.jpg" alt="ready" width="600" height="300">

	</div>


  </body>

</html>
