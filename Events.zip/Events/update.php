<!DOCTYPE html>
<html lang="en">



	<head>

		<meta charset="utf-8"/>
		<title> Aston Events </title>
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons"
	    rel="stylesheet">
	  <link href="https://cdnjs.cloudflare.com/ajax/libs/normalize/4.2.0/normalize.min.css" rel="stylesheet" />
		<link href="addEvent.css" rel="stylesheet" />
		<a href="http://www.aston.ac.uk/"><img src="Aston-logo.jpg" height="80px" width="250px"/> </a>

	</head>


	<body>

		<header id="main-header">
		<h1> Aston Event </h1>

    <div class="welcome">

    <?php
    session_start();

    if (isset($_SESSION['email'])){
      echo "Welcome Back ".$_SESSION['email'];
    }else {
      header('location:index.php');
    }

    $parameterId = $_GET['id'];
    include('connect.php');
    try{
      $sqlstr = "SELECT * FROM events where eventId='$parameterId'";
			$rows=$db->query($sqlstr);
      //loop through all the returned records and display them in a table
      foreach ($rows as $row) {
      $event=$row['event'];
      $time=$row['time'];
      $description=$row['description'];
      $organiser=$row['organiser'];
      $email=$row['email'];
		  $type=$row['type'];
      $date=$row['date'];
      $venue=$row['venue'];
      $image= $row['image'];
    }

    } catch (PDOException $ex){
      //this catches the exception when the query is thrown
      echo "Sorry, a database error occurred. Please try again.<br> ";
      echo "Error details:". $ex->getMessage();
    }
    ?>
  </div>


		<ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="event.php">Events</a></li>
		<li><a href="contactUs.php">Contact Us</a></li>
    <li><a href="index.php">Log Out</a></li>
		</ul>

		</header>

		<form class="event" action="updateEvent.php" method="post" enctype="multipart/form-data">
			<div class="header2">
			 <h2>Orgnaise Your Own Event</h2>
		 </div>

		 <div class = "wrap">

        <label class ="organiser">Organiser Details</label>

				<br> <br>
			 <input value="<?php echo $organiser;?>" type = "text" name="organiser" placeholder="Name Of Organiser">
			 <input value="<?php echo $email;?>" type="email"name="email"placeholder="Organiser email"pattern=".+\.ac\.uk"title="Please enter a Aston University email address"/>

			 <p> </P>
       <label class ="details">Event Details</label>

			 <br> </br>
			<input value="<?php echo $event;?>" type = "text" name="name" placeholder="Name Of Event">

			<select value="<?php echo $type;?>" name="type">


        <option value="sport">Sport (e.g. Football, Swimming, Cricket etc.)</option>
        <option value="culture">Culture (e.g. Hindu, Jewish, Chinese etc.)</option>
				<option value="other">Others (Music, Photography etc.)</option>
      </select>


			<input value="<?php echo $date;?>" type="date" name="date">
			<input type="time" value="<?php echo $time;?>" name="time">

			<input value="<?php echo $venue;?>" type = "text" name="venue" placeholder="Venue">

      <br> </br>
			<label class ="description">Event Description</label>
			<div class="box">
			<textarea value="<?php echo $description;?>" name="comments" style="width:48.5%;height:140px;border:none;padding:2%;font:18px/30px sans-serif;">
			</textarea>
			</div>

			<br> </br>
			<label class ="image">Add Image To Promote Event</label>
			<b class="multiple"> Select more than one file when when browsing for files. </b>

			<br> </br>
			<div class="file">
			 <font color="yellow">  current image: <?php echo '<img src="data:image/jpeg;base64,'.base64_encode($row['image']) .'" />'?></div><div>
      Change current pic  <input type="file" name="image" /> </font>
			 <br> </br>

			 <p> </p>
			 <input type="submit" value= "update" name="update"></form>

       <a href="table.php?id=<?php echo $parameterId?>"><font color="yellow">cancel</font><a/>
		 </div>

		</form>

		</div>


  </body>

</html>
