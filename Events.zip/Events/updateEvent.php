<?php

include('connect.php');
session_start();
// only run the php script if form is submitted
if (isset($_POST["update"])) {


  $organiser = $_POST['organiser'];
  $email = $_POST['email'];
  $name = $_POST['name'];
  $type = $_POST['type'];
  $date = $_POST['date'];
  $time = $_POST['time'];
  $venue = $_POST['venue'];
  $description = $_POST['comments'];


  if (empty($organiser))
  {
    echo '<a href="addEvent.php">Please type in your name<br /></a>';
      return false;
  }

  if (empty($email))
  {
  echo '<a href="addEvent.php">Please type in your email<br /></a>';
  return false;
  }

  if (empty($name))
  {
    echo '<a href="addEvent.php">Please type in the name of your event<br /></a>';
  return false;
  }

  if (empty($type))
  {
  echo '<a href="addEvent.php">Please specify the type of your event<br /></a>';
  return false;
  }

  if (empty($date))
  {
  echo '<a href="addEvent.php">please specify the date of your event<br /></a>';
  return false;
  }

  if (empty($time))
  {

  echo '<a href="addEvent.php">please specify the time of your event<br /></a>';
  return false;
  }

  if (empty($venue))
  {
  echo '<a href="addEvent.php">please specify the venue of your event<br /></a>';
  return false;
  }

  if (empty($description))
  {
  echo '<a href="addEvent.php">please give a description of your event<br /></a>';
  return false;
  }

  $image= $_POST['image'];
  $image = addslashes(file_get_contents($_FILES['image']['tmp_name']));
  if($image==""){
    try{
      // use the form data to create a insert SQL and  add a event record
      $sth=$db->prepare("UPDATE events SET organiser='$organiser',email='$email',event='$name',type='$type',date='$date',time='$time',venue='$venue',description='$description'");
      $sth->execute(array($organiser,$email,$name,$type,$date,$time,$venue,$description));
      header('location:event.php');
      exit();

    } catch (PDOException $ex){
      //this catches the exception when it is thrown
      echo "Sorry, a database error occurred when trying to insert a record. Please try again.<br> ";
      echo "Error details:". $ex->getMessage();
      exit();
    }
  }

  $file_type = $_FILES['image']['type']; //returns the mimetype

  $allowed = array("image/jpeg", "image/gif");

  if(!in_array($file_type, $allowed)) {
        echo '<a href="addEvent.php">Only jpg and gif files are allowed<br /></a>';
    return false;
  }

  try{
    // use the form data to create a insert SQL and  add a event record
    $sth=$db->prepare("UPDATE events SET organiser='$organiser',email='$email',event='$name',type='$type',date='$date',time='$time',venue='$venue',description='$description',image='$image'");
    $sth->execute(array($organiser,$email,$name,$type,$date,$time,$venue,$description,$image));
    header('location:event.php');


  } catch (PDOException $ex){
    //this catches the exception when it is thrown
    echo "Sorry, a database error occurred when trying to insert a record. Please try again.<br> ";
    echo "Error details:". $ex->getMessage();
  }

} else {

  echo "failed";
}

  ?>
