<!DOCTYPE html>
<html>


<?php
    if(!isset($_SESSION))
    {
        session_start();
    }
?>


<head>

  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.css" />
  <link rel="stylesheet" href="viewEvent.css" />
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" />
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
  <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.js"></script>

  <script>$(document).ready(function() {
    $('#events').DataTable( {
    } );} );</script>

  </head>


  <body>

    <div class="content container" style="width: 30%;">

    <?php include('connect.php');?>

    <h1>Events</h1>
    <table id= "events" class="display">

      <thead>
        <tr>
          <th>event</th>
          <th>time</th>
          <th>description</th>
          <th>More detail</th>
          

        </tr>
      </thead>


    <?php
    try{
      $sqlstr = "SELECT * FROM events";

      if( isset($_SESSION['email'])){

        if(isset($_GET['sort'])){
          $email = $_SESSION['email'];
          $sqlstr = "SELECT * FROM events WHERE email = '$email'";
        }
      }

      $rows=$db->query($sqlstr);

      foreach ($rows as $row) {
        echo  "<tr><td>" . $row['event'] . "</td><td>" .$row['time'] . "</td><td>" .  $row['description'] . "</td><td>".
        '<a href= "table.php?id=' .'">view</a>'.
        "</td></tr>";
      }
      echo "</table> <br>";

    } catch (PDOException $ex){

      echo "Sorry, a database error occurred when querying the vehicle records. Please try again.<br> ";
      echo "Error details:". $ex->getMessage();
    }
    ?>

    </div>

<form class="back" action="event.php" method="post">

<button> Go Back </button>

</form>

<?php
    if( isset($_SESSION['email'])){

      if(isset($_GET['sort'])){
        ?>
        <a href="viewEvent.php?"><input type="submit" name="my_events" class="change_table" value="Show all the events"/></a>
        <?php
      } else {
      ?>
        <a href="viewEvent.php?sort=1"><input type="submit" name="my_events" class="change_table" value="My events"/></a>
      <?php
      }
    }
     ?>

  </body>
</html>
